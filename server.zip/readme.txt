This datapack and resource pack were created by Origano.
You are not permitted to distribute them as your own.
If you use them in your projects, you must include proper credit to the original creator.
https://modrinth.com/project/depths-below

Special thanks to Objmc for making the entity 3d model possible, here's a link to its github:
https://github.com/Godlander/objmc